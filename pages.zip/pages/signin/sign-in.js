
var app = getApp();
var calendarData;
var date;
var calendarDay;
Page({
  calendarSign: function () {
    calendarData[date] = date;
    calendarDay = calendarDay + 1;
    wx.setStorageSync("calendarData", calendarData);
    wx.setStorageSync("calendarDay", calendarDay);

    wx.showToast({
      title: '签到成功',
      icon: 'success',
      duration: 1500
    })
    this.setData({

      calendarData: calendarData,
      calendarDay: calendarDay
    })
  },
  onLoad: function () {
    var mydate = new Date();
    var year = mydate.getFullYear();
    var month = mydate.getMonth() + 1;
    date = mydate.getDate();
    var day = mydate.getDay();
    var n = 7 - ((date - day) % 7);
    var monthDaySize;
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
      monthDaySize = 31;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
      monthDaySize = 30;
    } else if (month == 2) {
      if ((year - 2000) % 4 == 0) {
        monthDaySize = 29;
      } else {
        monthDaySize = 28;
      }
    };
    if (wx.getStorageSync("calendarData") == null || wx.getStorageSync("calendarData") == '') {
      wx.setStorageSync("calendarData", new Array(monthDaySize));
    };
    if (wx.getStorageSync("calendarDay") == null || wx.getStorageSync("calendarDay") == '') {
      wx.setStorageSync("calendarDay", 0);
    }
    calendarData = wx.getStorageSync("calendarData")
    calendarDay = wx.getStorageSync("calendarDay")
    this.setData({
      year: year,
      month: month,
      n: n,
      monthDaySize: monthDaySize,
      date: date,
      calendarData: calendarData,
      calendarDay: calendarDay
    })
  }
})
